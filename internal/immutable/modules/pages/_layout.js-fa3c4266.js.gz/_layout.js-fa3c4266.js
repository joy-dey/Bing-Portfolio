import { p } from "../../chunks/_layout-9a8b0c19.js";
export {
  p as prerender
};
