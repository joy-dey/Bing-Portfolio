import { default as default2 } from "../components/pages/_page.svelte-308ed1c0.js";
export {
  default2 as component
};
