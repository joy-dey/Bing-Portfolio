import { default as default2 } from "../components/error.svelte-ecdba6d5.js";
export {
  default2 as component
};
