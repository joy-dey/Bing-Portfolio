import { default as default2 } from "../components/pages/contact/_page.svelte-95cb64f2.js";
export {
  default2 as component
};
