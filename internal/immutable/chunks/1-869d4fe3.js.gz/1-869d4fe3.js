import { default as default2 } from "../components/error.svelte-a033f204.js";
export {
  default2 as component
};
