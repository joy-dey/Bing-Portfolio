import { _ } from "./_layout-9a8b0c19.js";
import { default as default2 } from "../components/layout.svelte-e24b3401.js";
export {
  default2 as component,
  _ as universal
};
