import { default as default2 } from "../components/pages/_page.svelte-72598473.js";
export {
  default2 as component
};
