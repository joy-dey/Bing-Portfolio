import { default as default2 } from "../components/pages/about/_page.svelte-23a915df.js";
export {
  default2 as component
};
