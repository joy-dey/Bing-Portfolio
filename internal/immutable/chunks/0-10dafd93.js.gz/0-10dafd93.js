import { _ } from "./_layout-9a8b0c19.js";
import { default as default2 } from "../components/pages/_layout.svelte-103d7d80.js";
export {
  default2 as component,
  _ as universal
};
